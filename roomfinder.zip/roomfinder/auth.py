from flask import Blueprint, render_template, request, redirect, flash
from flask_login import login_user, logout_user, login_required
from werkzeug.security import generate_password_hash, check_password_hash
from models import db, User

auth = Blueprint("auth", __name__)


# ---------------- LOGIN ----------------
@auth.route("/login", methods=["GET", "POST"])
def login():

    if request.method == "POST":

        email = request.form.get("email")
        password = request.form.get("password")

        user = User.query.filter_by(email=email).first()

        # Email not found
        if not user:
            flash("Email not registered", "error")
            return redirect("/login")

        # Password incorrect
        if not check_password_hash(user.password, password):
            flash("Incorrect password", "error")
            return redirect("/login")

        # Correct login
        login_user(user)
        flash("Login successful", "success")
        
        # If user already has a role, redirect to appropriate dashboard
        if user.role == "provider":
            return redirect("/provider/dashboard")
        elif user.role == "receiver":
            return redirect("/receiver/browse")
        else:
            return redirect("/role")

    return render_template("login.html")


# ---------------- REGISTER ----------------
@auth.route("/register", methods=["GET", "POST"])
def register():

    if request.method == "POST":

        name = request.form.get("name")
        email = request.form.get("email")
        password = request.form.get("password")
        confirm_password = request.form.get("confirm_password")

        # Basic empty check
        if not name or not email or not password:
            flash("All fields are required", "error")
            return redirect("/register")

        # Check password match
        if password != confirm_password:
            flash("Passwords do not match", "error")
            return redirect("/register")

        # Check existing email
        existing_user = User.query.filter_by(email=email).first()
        if existing_user:
            flash("Email already registered. Please login instead.", "error")
            return redirect("/login")

        # Optional password length rule
        if len(password) < 6:
            flash("Password must be at least 6 characters", "error")
            return redirect("/register")

        # Hash password
        hashed_password = generate_password_hash(password)

        # Create new user
        new_user = User(
            name=name,
            email=email,
            password=hashed_password
        )

        db.session.add(new_user)
        db.session.commit()

        flash("Account created successfully!", "success")
        login_user(new_user)

        return redirect("/role")

    return render_template("register.html")


# ---------------- LOGOUT ----------------
@auth.route("/logout")
@login_required
def logout():
    logout_user()
    flash("Logged out successfully")
    return redirect("/")

