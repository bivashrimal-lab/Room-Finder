import os
from flask import Flask, render_template, redirect, request, flash
from flask_login import LoginManager, login_required, current_user
from werkzeug.utils import secure_filename

from models import db, User, Property, Inquiry, PropertyFacility
from auth import auth

app = Flask(__name__)

app.config["SECRET_KEY"] = "supersecretkey"
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///database.db"
app.config["UPLOAD_FOLDER"] = "static/uploads/properties"
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False


os.makedirs(app.config["UPLOAD_FOLDER"], exist_ok=True)

db.init_app(app)

login_manager = LoginManager()
login_manager.login_view = "auth.login"
login_manager.init_app(app)

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

app.register_blueprint(auth)

with app.app_context():
    db.create_all()

# ---------------- HOME ----------------

@app.route("/")
def index():
    properties = Property.query.all()
    return render_template("index.html", properties=properties)

# ---------------- ROLE ----------------

@app.route("/role")
@login_required
def role_selection():
    redirect_to = request.args.get("redirect", "")
    
    if current_user.role == "provider" and redirect_to != "receiver":
        return redirect("/provider/dashboard")
    elif current_user.role == "receiver" and redirect_to != "provider":
        return redirect("/receiver/browse")
    elif current_user.role and current_user.role.strip() != "" and redirect_to == "":
        if current_user.role == "provider":
            return redirect("/provider/dashboard")
        else:
            return redirect("/receiver/browse")
    
    return render_template("role_selection.html", redirect_to=redirect_to)

@app.route("/set_role/<role>")
@login_required
def set_role(role):
    current_user.role = role
    db.session.commit()

    if role == "provider":
        return redirect("/provider/dashboard")
    else:
        return redirect("/receiver/browse")

# Role checking decorator
from functools import wraps

def role_required(required_role):
    def decorator(f):
        @wraps(f)
        @login_required
        def decorated_function(*args, **kwargs):
            if current_user.role != required_role:
                flash(f"Please select {required_role} role to access this page", "error")
                return redirect("/role")
            return f(*args, **kwargs)
        return decorated_function
    return decorator

# ---------------- PROVIDER ----------------

@app.route("/provider/dashboard")
@login_required
def provider_dashboard():
    if current_user.role != "provider":
        flash("Please select provider role to access this page", "error")
        return redirect("/role?redirect=provider")
    properties = Property.query.filter_by(owner_id=current_user.id).all()
    return render_template("provider/provider_dashboard.html", properties=properties)

@app.route("/provider/add", methods=["GET", "POST"])
@login_required
def add_property():
    if current_user.role != "provider":
        flash("Please select provider role to access this page", "error")
        return redirect("/role?redirect=provider")
    if request.method == "POST":
        image = request.files.get("image")
        filename = "default.jpg"
        if image and image.filename:
            filename = secure_filename(image.filename)
            image.save(os.path.join(app.config["UPLOAD_FOLDER"], filename))

        property_type = request.form.get("property_type")
        room_number = request.form.get("room_number")
        flat_rooms = request.form.get("flat_rooms")
        latitude = request.form.get("latitude")
        longitude = request.form.get("longitude")

        facilities_list = request.form.getlist("facilities")
        
        new_property = Property(
            owner_id=current_user.id,
            title=request.form["title"],
            description=request.form["description"],
            price=request.form["price"],
            location=request.form["location"],
            size=request.form["size"],
            facilities=",".join(facilities_list) if facilities_list else "",
            phone=request.form["phone"],
            image=filename,
            property_type=property_type,
            room_number=room_number,
            flat_rooms=flat_rooms,
            latitude=latitude,
            longitude=longitude
        )

        db.session.add(new_property)
        db.session.commit()
        
        # Save facilities with prices to PropertyFacility table
        for facility in facilities_list:
            price_type = request.form.get(f"facility_{facility}_price_type")
            price = request.form.get(f"facility_{facility}_price")
            
            if price_type:
                facility_entry = PropertyFacility(
                    property_id=new_property.id,
                    facility_name=facility,
                    price_type=price_type,
                    price=int(price) if price and price.isdigit() else None
                )
                db.session.add(facility_entry)
        
        db.session.commit()
        return redirect("/provider/success")

    return render_template("provider/add_property.html")

@app.route("/provider/success")
@login_required
def provider_success():
    return render_template("provider/success.html")

@app.route("/provider/edit/<int:id>", methods=["GET", "POST"])
@login_required
def edit_property(id):
    if current_user.role != "provider":
        flash("Please select provider role to access this page", "error")
        return redirect("/role?redirect=provider")
    
    property = Property.query.get_or_404(id)
    
    if property.owner_id != current_user.id:
        flash("You don't have permission to edit this property", "error")
        return redirect("/provider/dashboard")
    
    # Get existing facilities from PropertyFacility table
    existing_facilities = PropertyFacility.query.filter_by(property_id=id).all()
    facility_dict = {f.facility_name: f for f in existing_facilities}
    
    if request.method == "POST":
        property.title = request.form["title"]
        property.description = request.form["description"]
        property.price = request.form["price"]
        property.location = request.form["location"]
        property.size = request.form["size"]
        property.facilities = request.form["facilities"]
        property.phone = request.form["phone"]
        property.property_type = request.form.get("property_type")
        property.room_number = request.form.get("room_number")
        property.flat_rooms = request.form.get("flat_rooms")
        property.latitude = request.form.get("latitude")
        property.longitude = request.form.get("longitude")
        
        image = request.files.get("image")
        if image and image.filename:
            filename = secure_filename(image.filename)
            image.save(os.path.join(app.config["UPLOAD_FOLDER"], filename))
            property.image = filename
        
        # Delete existing facilities and save new ones
        PropertyFacility.query.filter_by(property_id=id).delete()
        
        facilities_list = request.form.getlist("facilities")
        for facility in facilities_list:
            price_type = request.form.get(f"facility_{facility}_price_type")
            price = request.form.get(f"facility_{facility}_price")
            
            if price_type:
                facility_entry = PropertyFacility(
                    property_id=property.id,
                    facility_name=facility,
                    price_type=price_type,
                    price=int(price) if price and price.isdigit() else None
                )
                db.session.add(facility_entry)
        
        db.session.commit()
        flash("Property updated successfully!", "success")
        return redirect("/provider/dashboard")
    
    return render_template("provider/edit_property.html", property=property, facility_dict=facility_dict)

@app.route("/provider/delete/<int:id>")
@login_required
def delete_property(id):
    if current_user.role != "provider":
        flash("Please select provider role to access this page", "error")
        return redirect("/role?redirect=provider")
    
    property = Property.query.get_or_404(id)
    
    if property.owner_id != current_user.id:
        flash("You don't have permission to delete this property", "error")
        return redirect("/provider/dashboard")
    
    # Delete associated facilities
    PropertyFacility.query.filter_by(property_id=id).delete()
    
    db.session.delete(property)
    db.session.commit()
    flash("Property deleted successfully!", "success")
    return redirect("/provider/dashboard")

# ---------------- RECEIVER ----------------

@app.route("/receiver/browse")
@login_required
def browse_rooms():
    if current_user.role != "receiver":
        flash("Please select receiver role to browse rooms", "error")
        return redirect("/role?redirect=receiver")
    properties = Property.query.all()
    
    # Get all facilities and organize by property_id
    all_facilities = PropertyFacility.query.all()
    facilities_by_property = {}
    for facility in all_facilities:
        if facility.property_id not in facilities_by_property:
            facilities_by_property[facility.property_id] = []
        facilities_by_property[facility.property_id].append(facility)
    
    return render_template("receiver/browse_room.html", properties=properties, facilities_by_property=facilities_by_property)

@app.route("/receiver/room/<int:id>", methods=["GET", "POST"])
def room_detail(id):
    property = Property.query.get_or_404(id)
    
    # Get facilities for this property
    facilities = PropertyFacility.query.filter_by(property_id=id).all()

    if request.method == "POST":
        message = request.form["message"]

        inquiry = Inquiry(
            property_id=id,
            user_id=current_user.id if current_user.is_authenticated else None,
            message=message
        )

        db.session.add(inquiry)
        db.session.commit()

        return redirect("/receiver/request_sent")

    return render_template("receiver/room_details.html", property=property, facilities=facilities)

@app.route("/receiver/request_sent")
def request_sent():
    return render_template("receiver/request_sent.html")


# ---------------- RUN ----------------

if __name__ == "__main__":
    app.run(debug=True)

