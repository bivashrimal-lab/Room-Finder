from flask_sqlalchemy import SQLAlchemy
from flask_login import UserMixin
from datetime import datetime

db = SQLAlchemy()


class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(150))
    email = db.Column(db.String(150), unique=True)
    password = db.Column(db.String(200))
    google_id = db.Column(db.String(200), nullable=True)
    role = db.Column(db.String(20), nullable=True)  # provider / receiver


class Property(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    owner_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    title = db.Column(db.String(200))
    description = db.Column(db.Text)
    price = db.Column(db.Integer)
    location = db.Column(db.String(150))
    size = db.Column(db.String(100))
    facilities = db.Column(db.String(300))
    phone = db.Column(db.String(20))
    image = db.Column(db.String(200))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Additional property fields
    property_type = db.Column(db.String(50))  # Room or Flat
    room_number = db.Column(db.Integer, nullable=True)
    flat_rooms = db.Column(db.Integer, nullable=True)
    latitude = db.Column(db.String(100), nullable=True)
    longitude = db.Column(db.String(100), nullable=True)


class Inquiry(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    property_id = db.Column(db.Integer)
    user_id = db.Column(db.Integer)
    message = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


class PropertyFacility(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    property_id = db.Column(db.Integer, db.ForeignKey('property.id'))
    facility_name = db.Column(db.String(100))
    price_type = db.Column(db.String(20))  # 'free', 'monthly', 'discuss'
    price = db.Column(db.Integer, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
