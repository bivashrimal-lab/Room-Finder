document.addEventListener("DOMContentLoaded", function () {

    const searchInput = document.getElementById("searchInput");
    const cards = document.querySelectorAll(".room-card");

    document.getElementById("image").addEventListener("change", function() {
        const fileName = this.files.length > 0 ? this.files[0].name : "No file selected";
        document.getElementById("file-name").textContent = fileName;
    });

    if (!searchInput) return;

    searchInput.addEventListener("keyup", function () {

        const value = searchInput.value.toLowerCase().trim();

        cards.forEach(function (card) {

            const title = card.dataset.title || "";
            const location = card.dataset.location || "";

            if (title.includes(value) || location.includes(value)) {
                card.style.display = "";
            } else {
                card.style.display = "none";
            }

        });

    });

});
