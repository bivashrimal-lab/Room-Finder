import sqlite3
import os

# Connect to the database
db_path = os.path.join(os.path.dirname(__file__), 'instance', 'database.db')

if os.path.exists(db_path):
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    # Add missing columns to property table
    columns_to_add = [
        ("property_type", "VARCHAR(50)"),
        ("room_number", "INTEGER"),
        ("flat_rooms", "INTEGER"),
        ("latitude", "VARCHAR(100)"),
        ("longitude", "VARCHAR(100)"),
        ("parking", "BOOLEAN DEFAULT 0"),
        ("parking_price", "VARCHAR(50)"),
        ("wifi", "BOOLEAN DEFAULT 0"),
        ("wifi_price", "VARCHAR(50)"),
        ("water", "BOOLEAN DEFAULT 0"),
        ("water_price", "VARCHAR(50)")
    ]
    
    for col_name, col_type in columns_to_add:
        try:
            cursor.execute(f"ALTER TABLE property ADD COLUMN {col_name} {col_type}")
            print(f"Added column: {col_name}")
        except sqlite3.OperationalError as e:
            if "duplicate column name" in str(e).lower():
                print(f"Column {col_name} already exists")
            else:
                print(f"Error adding {col_name}: {e}")
    
    conn.commit()
    conn.close()
    print("Migration completed!")
else:
    print("Database not found. Please run app.py first to create the database.")

